package com.cg.spring.springbeapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.springbeapp.bean.Customer;
import com.cg.spring.springbeapp.bean.Product;
import com.cg.spring.springbeapp.bean.WishList;
import com.cg.spring.springbeapp.service.ICustomerService;

@RestController
public class PlpController {

	@Autowired
	ICustomerService service;

	@RequestMapping("/show")
	public List<Product> showAll() {
		return service.showAll();
	}
	@RequestMapping("/get/{customer_email}")
	public List<Product> getProducts(@PathVariable String customer_email){
		return service.getProducts(customer_email);
	}
	
	@RequestMapping("/add/{customer_email}/{product_id}")
	public boolean addProduct(@PathVariable String customer_email,@PathVariable int product_id){
		return service.addProduct(customer_email,product_id);
	}
	@RequestMapping("/delete/{customer_email}/{product_id}")
	public boolean deleteProduct(@PathVariable String customer_email,@PathVariable int product_id){
		return service.deleteProduct(customer_email,product_id);
	}

}
