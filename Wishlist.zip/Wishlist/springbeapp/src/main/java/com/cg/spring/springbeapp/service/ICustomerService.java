package com.cg.spring.springbeapp.service;

import java.util.List;

import com.cg.spring.springbeapp.bean.Customer;
import com.cg.spring.springbeapp.bean.Product;
import com.cg.spring.springbeapp.bean.WishList;

public interface ICustomerService {

	public List<Product> showAll();
	public List<Product> getProducts(String customer_email);
	public boolean addProduct(String customer_email,int product_id);
	public boolean deleteProduct(String customer_email,int product_id);
}
