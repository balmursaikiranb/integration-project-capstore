package com.cg.spring.springbeapp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.springbeapp.bean.Customer;
import com.cg.spring.springbeapp.bean.Product;
import com.cg.spring.springbeapp.bean.WishList;
import com.cg.spring.springbeapp.repo.ICustomerRepo;
import com.cg.spring.springbeapp.repo.IProductRepo;
import com.cg.spring.springbeapp.repo.IWishListRepo;
import com.cg.spring.springbeapp.repo.IWishListRepository;

@Service
public class CustomerServiceImpl implements ICustomerService {
	@Autowired
	ICustomerRepo repo;
	@Autowired
	IProductRepo repo1;
	@Autowired
	IWishListRepo repo2;
@Autowired
IWishListRepository repository;
	@Override
	public List<Product> showAll() {
		List<Product> list = new ArrayList<>();
		/*repo.createQuery("Select product_id from product where customer_email=''");*/
		repo1.findAll().forEach(list::add);
		
		return list;
	}

	@Override
	public List<Product> getProducts(String customer_email) {
		List<WishList> list=new ArrayList<>();
		List<Product> customer_wishlist=new ArrayList<>();
		repo2.findAll().forEach(list::add);
		for (WishList wishList : list) {
			if(wishList.getCustomer_email().equals(customer_email))
			{
				//customer_wishlist.add(wishList);
			int product_id=wishList.getProduct_id();
			
			customer_wishlist.add(repo1.findById(product_id).get());
			}
		}
		return customer_wishlist;
		/*return repository.getProducts(customer_email);*/
	}

	@Override
	public boolean addProduct(String customer_email, int product_id) {
		List<WishList> list=new ArrayList<>();
		repo2.findAll().forEach(list::add);
		for (WishList wishList : list) {
			if(wishList.getCustomer_email().equals(customer_email)&&(wishList.getProduct_id()==product_id))
			{
				return false;
			}
		}
		WishList wl=new WishList();
		wl.setCustomer_email(customer_email);
		wl.setProduct_id(product_id);
		repo2.save(wl);
		return true;
	}

	@Override
	public boolean deleteProduct(String customer_email, int product_id) {
		List<WishList> list=new ArrayList<>();
		repo2.findAll().forEach(list::add);
		for (WishList wishList : list) {
			if((wishList.getCustomer_email().equals(customer_email))&&(wishList.getProduct_id()==product_id))
			{
				repo2.delete(wishList);
				return true;
			}
		}
		return false;
	}

}
