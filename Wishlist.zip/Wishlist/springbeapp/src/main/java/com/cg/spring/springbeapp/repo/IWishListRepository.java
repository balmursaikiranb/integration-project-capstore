package com.cg.spring.springbeapp.repo;

import java.util.List;

import com.cg.spring.springbeapp.bean.Product;
import com.cg.spring.springbeapp.bean.WishList;

public interface IWishListRepository {

	public List<WishList> showAll();
	public List<Product> getProducts(String customer_email);
	public boolean addProduct(String customer_email,int product_id);
	public boolean deleteProduct(String customer_email,int product_id);
}
