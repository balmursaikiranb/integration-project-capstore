package com.cg.spring.springbeapp.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.spring.springbeapp.bean.Product;
import com.cg.spring.springbeapp.bean.WishList;
@Repository
public class WishListRepository implements IWishListRepository{

	@PersistenceContext
@Autowired
EntityManager em;

	@Override
	public List<WishList> showAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getProducts(String customer_email) {
		Query q=em.createQuery("SELECT e.product_id FROM wish_list e WHERE customer_email='"+customer_email+"'");
		List<Product> list=new ArrayList<>();
		list=q.getResultList();
		return list;
	}

	@Override
	public boolean addProduct(String customer_email, int product_id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteProduct(String customer_email, int product_id) {
		// TODO Auto-generated method stub
		return false;
	} 
	
}
