package com.cg.spring.springbeapp.bean;

import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class Product {
	@Id
	private int product_id;
	private String product_name;
	private double product_price;
	private String product_description;
	private String product_modelname;
	private long product_viewcount;
	private String product_warranty;
	private long product_soldcount;
	private String product_type;
	private String product_returnpolicy;
	private String product_category;
	
	private String merchant_email;
private double discount;	
private long product_count;
private String product_imagename;
	public Product() {
		
	}
	public Product(int product_id, String product_name, double product_price, String product_description,
			String product_modelname, long product_viewcount, String product_warranty, long product_soldcount,
			String product_type, String product_returnpolicy, String product_category, String merchant_email) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.product_price = product_price;
		this.product_description = product_description;
		this.product_modelname = product_modelname;
		this.product_viewcount = product_viewcount;
		this.product_warranty = product_warranty;
		this.product_soldcount = product_soldcount;
		this.product_type = product_type;
		this.product_returnpolicy = product_returnpolicy;
		this.product_category = product_category;
		this.merchant_email = merchant_email;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public double getProduct_price() {
		return product_price;
	}
	public void setProduct_price(double product_price) {
		this.product_price = product_price;
	}
	public String getProduct_description() {
		return product_description;
	}
	public void setProduct_description(String product_description) {
		this.product_description = product_description;
	}
	public String getProduct_modelname() {
		return product_modelname;
	}
	public void setProduct_modelname(String product_modelname) {
		this.product_modelname = product_modelname;
	}
	public long getProduct_viewcount() {
		return product_viewcount;
	}
	public void setProduct_viewcount(long product_viewcount) {
		this.product_viewcount = product_viewcount;
	}
	public String getProduct_warranty() {
		return product_warranty;
	}
	public void setProduct_warranty(String product_warranty) {
		this.product_warranty = product_warranty;
	}
	public long getProduct_soldcount() {
		return product_soldcount;
	}
	public void setProduct_soldcount(long product_soldcount) {
		this.product_soldcount = product_soldcount;
	}
	public String getProduct_type() {
		return product_type;
	}
	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}
	public String getProduct_returnpolicy() {
		return product_returnpolicy;
	}
	public void setProduct_returnpolicy(String product_returnpolicy) {
		this.product_returnpolicy = product_returnpolicy;
	}
	public String getProduct_category() {
		return product_category;
	}
	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}
	public String getMerchant_email() {
		return merchant_email;
	}
	public void setMerchant_email(String merchant_email) {
		this.merchant_email = merchant_email;
	}
	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", product_name=" + product_name + ", product_price="
				+ product_price + ", product_description=" + product_description + ", product_modelname="
				+ product_modelname + ", product_viewcount=" + product_viewcount + ", product_warranty="
				+ product_warranty + ", product_soldcount=" + product_soldcount + ", product_type=" + product_type
				+ ", product_returnpolicy=" + product_returnpolicy + ", product_category=" + product_category
				+ ", merchant_email=" + merchant_email + "]";
	}
	
}
