package com.cg.spring.springbeapp.repo;



import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.springbeapp.bean.Customer;

@Repository
public interface ICustomerRepo extends CrudRepository<Customer, String> {

}
