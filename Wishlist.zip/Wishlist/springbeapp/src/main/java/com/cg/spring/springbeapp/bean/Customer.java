package com.cg.spring.springbeapp.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	/*@GeneratedValue(strategy = GenerationType.AUTO)*/
	private String customer_email;
	private String customer_name;
	private String customer_phone;
	private String customer_address;
	private String customer_password;
	private String customer_prodcount;

	public Customer() {

	}

	public String getCustomer_email() {
		return customer_email;
	}

	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getCustomer_phone() {
		return customer_phone;
	}

	public void setCustomer_phone(String customer_phone) {
		this.customer_phone = customer_phone;
	}

	public String getCustomer_address() {
		return customer_address;
	}

	public void setCustomer_address(String customer_address) {
		this.customer_address = customer_address;
	}

	public String getCustomer_password() {
		return customer_password;
	}

	public void setCustomer_password(String customer_password) {
		this.customer_password = customer_password;
	}

	public String getCustomer_prodcount() {
		return customer_prodcount;
	}

	public void setCustomer_prodcount(String customer_prodcount) {
		this.customer_prodcount = customer_prodcount;
	}

	public Customer(String customer_email, String customer_name, String customer_phone, String customer_address,
			String customer_password, String customer_prodcount) {
		super();
		this.customer_email = customer_email;
		this.customer_name = customer_name;
		this.customer_phone = customer_phone;
		this.customer_address = customer_address;
		this.customer_password = customer_password;
		this.customer_prodcount = customer_prodcount;
	}

	@Override
	public String toString() {
		return "Customer [customer_email=" + customer_email + ", customer_name=" + customer_name + ", customer_phone="
				+ customer_phone + ", customer_address=" + customer_address + ", customer_password=" + customer_password
				+ ", customer_prodcount=" + customer_prodcount + "]";
	}

	

}
