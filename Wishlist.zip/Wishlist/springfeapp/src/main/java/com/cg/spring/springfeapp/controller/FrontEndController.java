package com.cg.spring.springfeapp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.springfeapp.bean.Customer;
import com.cg.spring.springfeapp.bean.Product;
import com.cg.spring.springfeapp.bean.WishList;

@RestController
public class FrontEndController {

	@RequestMapping("/customers")
	public ModelAndView show()
	{
		RestTemplate rt=new RestTemplate();
		List<Customer> list=rt.getForObject("http://localhost:9190/show", ArrayList.class);
	/*	List<Customer> list=rt.getForObject("http://localhost:9190/show"?customer="+c, ArrayList.class);*/
		return new ModelAndView("display","cust",list);
	}
	@RequestMapping(value="/wishlist",method = RequestMethod.GET)
	public ModelAndView getProducts(/*@PathVariable String customer_email*/)
	{
		String customer_email="sai@gmail.com";
		RestTemplate rt=new RestTemplate();
		/*List<Customer> list=rt.getForObject("http://localhost:9190/show", ArrayList.class);*/
		
		/*List<Product> list=rt.getForObject("http://localhost:9190/get/"?=+c, ArrayList.class);*/
		List<Product> list=rt.getForObject("http://localhost:9190/get/"+customer_email, ArrayList.class);
		return new ModelAndView("display1","product",list);
	}
	
	@RequestMapping("/addtowishlist/{product_id}")
	public ModelAndView addProduct(@PathVariable int product_id)
	{
		String customer_email="sai@gmail.com";
		
		RestTemplate rt=new RestTemplate();
		/*List<Customer> list=rt.getForObject("http://localhost:9190/show", ArrayList.class);*/
		
		/*List<Product> list=rt.getForObject("http://localhost:9190/get/"?=+c, ArrayList.class);*/
		boolean pro=rt.getForObject("http://localhost:9190/add/"+customer_email+"/"+product_id,Boolean.class);
		if(pro)
		{
			return new ModelAndView("addedsuccess","wishlist",pro);
		}
		return new ModelAndView("addedfailed","wishlist",pro);
	}
	
	@RequestMapping("/remove/{product_id}")
	public ModelAndView aProduct(@PathVariable int product_id)
	{
		String customer_email="sai@gmail.com";
		
		RestTemplate rt=new RestTemplate();
		/*List<Customer> list=rt.getForObject("http://localhost:9190/show", ArrayList.class);*/
		
		/*List<Product> list=rt.getForObject("http://localhost:9190/get/"?=+c, ArrayList.class);*/
		boolean pro=rt.getForObject("http://localhost:9190/delete/"+customer_email+"/"+product_id,Boolean.class);
		if(pro)
		{
			return new ModelAndView("deletedsuccess","wishlist",pro);
		}
		return new ModelAndView("deletedfailed","wishlist",pro);
	}
	@RequestMapping("/index")
	public ModelAndView sayHello()
	{
		RestTemplate rt=new RestTemplate();
		List<Product> list=rt.getForObject("http://localhost:9190/show", ArrayList.class);
		return new ModelAndView("index","product",list);
		//return "index";
	}
	
}
