package com.cg.spring.springfeapp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.springfeapp.bean.Customer;
import com.cg.spring.springfeapp.bean.Product;

@Controller
public class JspController {

	@RequestMapping("/")
	public ModelAndView sayHello()
	{
		RestTemplate rt=new RestTemplate();
		List<Product> list=rt.getForObject("http://localhost:9190/show", ArrayList.class);
		return new ModelAndView("index","product",list);
		//return "index";
	}
}
