package com.cg.spring.springfeapp.bean;




public class WishList {
	
	
	private int sno;
	private String customer_email;
	private int product_id;
	public WishList() {
		
	}
	public WishList(String customer_email, int product_id) {
		super();
		this.customer_email = customer_email;
		this.product_id = product_id;
	}
	public String getCustomer_email() {
		return customer_email;
	}
	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id2) {
		this.product_id = product_id2;
	}
	@Override
	public String toString() {
		return "WishList [customer_email=" + customer_email + ", product_id=" + product_id + "]";
	}
	
	
}
