package com.cg.PlpFrontEnd.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.PlpFrontEnd.beans.Product;

@Controller
public class JspController {

	/*
	 * @RequestMapping("/") public ModelAndView show() {
	 * 
	 * RestTemplate rt=new RestTemplate(); Product p=
	 * rt.getForObject("http://localhost:9999/getproducts/2",Product.class);
	 * //return new ModelAndView("display","obj",p); ModelAndView mv= new
	 * ModelAndView(); mv.addObject("obj",p); mv.setViewName("display"); return mv;
	 * }
	 */
	/*
	 * @RequestMapping("/") public String show() { return "index"; }
	 */
	@RequestMapping("/")
	public ModelAndView getProduct() {
		RestTemplate rt = new RestTemplate();
		List<Product> p = rt.getForObject("http://localhost:9999/getProducts", ArrayList.class);
		return new ModelAndView("index", "product", p);
	}

	/*
	 * @RequestMapping("/") public String showAll() { return "login"; }
	 */
	@RequestMapping("/payment")
	public String payment() {
		return "paymentpage1";
	}

	@RequestMapping("/credit")
	public String credit() {
		return "credit";
	}

	@RequestMapping("/netbanking")
	public String netbanking() {
		return "netbanking";
	}

	@RequestMapping("/netbanking2")
	public String netbanking2() {
		return "netbanking2";
	}

	@RequestMapping("/cashondelivery")
	public String cashondelivery() {
		return "cashondelivery";
	}

	@RequestMapping("/googlepay")
	public String tez() {
		return "googlepay";
	}

	@RequestMapping("/paytm")
	public String paytm() {
		return "paytm";
	}

	@RequestMapping("/wallet")
	public String wallet() {
		return "wallet";
	}

	@RequestMapping("/phonepe")
	public String phonepe() {
		return "phonepe";
	}

	@RequestMapping("/mobikwik")
	public String mobikwik() {
		return "mobikwik";
	}

	@RequestMapping("/profile")
	public String profilePage() {
		return "profile5";
	}

	@RequestMapping("/order")
	public String orderPage() {
		return "order5";
	}

	@RequestMapping("/wishlist")
	public String wishlistPage() {
		return "wishlist5";
	}

	@RequestMapping("/feed")
	public String feedbacktPage() {
		return "feedback5";
	}

	@RequestMapping("/ui")
	public String passwordPage() {
		return "ui5";
	}

	@RequestMapping("/common")
	public String feedbackPage() {
		return "common5";
	}

	@RequestMapping("/success1")
	public String successPage() {
		return "success15";
	}

	@RequestMapping("/login")
	public String loginPage() {
		return "login5";
	}

	@RequestMapping("/response")
	public String merchantPage() {
		return "merchantResponse5";
	}

	@RequestMapping("/success2")
	public String success2Page() {
		return "success25";
	}

	@RequestMapping("/indextwo")
	public String deliver() {
		return "indextwo";

	}

	@RequestMapping(value = "/status")
	public String status() {
		return "status";
	}
}
