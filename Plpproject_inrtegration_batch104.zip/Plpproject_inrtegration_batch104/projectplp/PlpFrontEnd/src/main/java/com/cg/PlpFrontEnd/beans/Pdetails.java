package com.cg.PlpFrontEnd.beans;

public class Pdetails {

	private String c_email;
	private String c_address;
	private int c_age;
	private int code;
	private String c_gender;
	private String c_name;
	private int c_phone_no;
	public Pdetails() {
	}
	public Pdetails(String c_email, String c_address, int c_age, int code, String c_gender, String c_name,
			int c_phone_no) {
		super();
		this.c_email = c_email;
		this.c_address = c_address;
		this.c_age = c_age;
		this.code = code;
		this.c_gender = c_gender;
		this.c_name = c_name;
		this.c_phone_no = c_phone_no;
	}
	public String getC_email() {
		return c_email;
	}
	public void setC_email(String c_email) {
		this.c_email = c_email;
	}
	public String getC_address() {
		return c_address;
	}
	public void setC_address(String c_address) {
		this.c_address = c_address;
	}
	public int getC_age() {
		return c_age;
	}
	public void setC_age(int c_age) {
		this.c_age = c_age;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getC_gender() {
		return c_gender;
	}
	public void setC_gender(String c_gender) {
		this.c_gender = c_gender;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	public int getC_phone_no() {
		return c_phone_no;
	}
	public void setC_phone_no(int c_phone_no) {
		this.c_phone_no = c_phone_no;
	} 
	
	
}
