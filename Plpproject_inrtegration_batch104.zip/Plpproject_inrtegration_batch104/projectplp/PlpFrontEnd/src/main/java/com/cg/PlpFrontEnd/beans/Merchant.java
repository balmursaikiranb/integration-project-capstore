package com.cg.PlpFrontEnd.beans;

public class Merchant {

		private String merchant_email ;
		private String  merchant_category ;
		private String merchant_ifsc_code ;
		private String merchant_location;
		private String merchant_mobile ;
		private String merchant_name ;
		private String merchant_account_number;
		private int rating;
		private String address;
		private int code;
		private String password;
		private String producttype;
		private int product_id;
		private String merchant_type;
		public Merchant() {
			
		}
		public Merchant(String merchant_email, String merchant_category, String merchant_ifsc_code,
				String merchant_location, String merchant_mobile, String merchant_name, String merchant_account_number,
				int rating, String address, int code, String password, String producttype, int product_id,
				String merchant_type) {
			super();
			this.merchant_email = merchant_email;
			this.merchant_category = merchant_category;
			this.merchant_ifsc_code = merchant_ifsc_code;
			this.merchant_location = merchant_location;
			this.merchant_mobile = merchant_mobile;
			this.merchant_name = merchant_name;
			this.merchant_account_number = merchant_account_number;
			this.rating = rating;
			this.address = address;
			this.code = code;
			this.password = password;
			this.producttype = producttype;
			this.product_id = product_id;
			this.merchant_type = merchant_type;
		}
		public String getMerchant_email() {
			return merchant_email;
		}
		public void setMerchant_email(String merchant_email) {
			this.merchant_email = merchant_email;
		}
		public String getMerchant_category() {
			return merchant_category;
		}
		public void setMerchant_category(String merchant_category) {
			this.merchant_category = merchant_category;
		}
		public String getMerchant_ifsc_code() {
			return merchant_ifsc_code;
		}
		public void setMerchant_ifsc_code(String merchant_ifsc_code) {
			this.merchant_ifsc_code = merchant_ifsc_code;
		}
		public String getMerchant_location() {
			return merchant_location;
		}
		public void setMerchant_location(String merchant_location) {
			this.merchant_location = merchant_location;
		}
		public String getMerchant_mobile() {
			return merchant_mobile;
		}
		public void setMerchant_mobile(String merchant_mobile) {
			this.merchant_mobile = merchant_mobile;
		}
		public String getMerchant_name() {
			return merchant_name;
		}
		public void setMerchant_name(String merchant_name) {
			this.merchant_name = merchant_name;
		}
		public String getMerchant_account_number() {
			return merchant_account_number;
		}
		public void setMerchant_account_number(String merchant_account_number) {
			this.merchant_account_number = merchant_account_number;
		}
		public int getRating() {
			return rating;
		}
		public void setRating(int rating) {
			this.rating = rating;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public int getCode() {
			return code;
		}
		public void setCode(int code) {
			this.code = code;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getProducttype() {
			return producttype;
		}
		public void setProducttype(String producttype) {
			this.producttype = producttype;
		}
		public int getProduct_id() {
			return product_id;
		}
		public void setProduct_id(int product_id) {
			this.product_id = product_id;
		}
		public String getMerchant_type() {
			return merchant_type;
		}
		public void setMerchant_type(String merchant_type) {
			this.merchant_type = merchant_type;
		}
		
}
