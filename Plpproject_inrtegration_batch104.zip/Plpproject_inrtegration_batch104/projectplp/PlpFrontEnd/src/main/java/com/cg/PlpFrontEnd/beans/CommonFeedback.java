package com.cg.PlpFrontEnd.beans;

public class CommonFeedback {
	private int product_id;
	private String customer_feedback;
	private String merchant_response;
	public CommonFeedback() {
	}
	public CommonFeedback(int product_id, String customer_feedback, String merchant_response) {
		super();
		this.product_id = product_id;
		this.customer_feedback = customer_feedback;
		this.merchant_response = merchant_response;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getCustomer_feedback() {
		return customer_feedback;
	}
	public void setCustomer_feedback(String customer_feedback) {
		this.customer_feedback = customer_feedback;
	}
	public String getMerchant_response() {
		return merchant_response;
	}
	public void setMerchant_response(String merchant_response) {
		this.merchant_response = merchant_response;
	}
	
	
}
