package com.cg.PlpFrontEnd.beans;

public class Inventory {

	private int product_id;
	private String merchant_email;
	private int product_count;
	private String product_name;
	public Inventory() {

	}
	public Inventory(int product_id, String merchant_email, int product_count, String product_name) {
		super();
		this.product_id = product_id;
		this.merchant_email = merchant_email;
		this.product_count = product_count;
		this.product_name = product_name;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getMerchant_email() {
		return merchant_email;
	}
	public void setMerchant_email(String merchant_email) {
		this.merchant_email = merchant_email;
	}
	public int getProduct_count() {
		return product_count;
	}
	public void setProduct_count(int product_count) {
		this.product_count = product_count;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	} 
	
	
}
