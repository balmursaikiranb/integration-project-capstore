package com.cg.PlpFrontEnd.beans;

public class Customer {

	private String customer_email;
	private int customer_refcode;
	private int code;
	private String password;
	private byte  vstatus;
	private String address;
	private String phonenumber;
	private String user_name;
	private String customer_gender;
	private int order_id;
	public Customer() {
		
	}
	public Customer(String customer_email, int customer_refcode, int code, String password, byte vstatus,
			String address, String phonenumber, String user_name, String customer_gender, int order_id) {
		super();
		this.customer_email = customer_email;
		this.customer_refcode = customer_refcode;
		this.code = code;
		this.password = password;
		this.vstatus = vstatus;
		this.address = address;
		this.phonenumber = phonenumber;
		this.user_name = user_name;
		this.customer_gender = customer_gender;
		this.order_id = order_id;
	}
	public String getCustomer_email() {
		return customer_email;
	}
	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}
	public int getCustomer_refcode() {
		return customer_refcode;
	}
	public void setCustomer_refcode(int customer_refcode) {
		this.customer_refcode = customer_refcode;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public byte getVstatus() {
		return vstatus;
	}
	public void setVstatus(byte vstatus) {
		this.vstatus = vstatus;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getCustomer_gender() {
		return customer_gender;
	}
	public void setCustomer_gender(String customer_gender) {
		this.customer_gender = customer_gender;
	}
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	} 
	
	
}
