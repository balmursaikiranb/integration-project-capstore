package com.cg.PlpFrontEnd.beans;

public class Orders {

	private int order_id;
	private String purchase_date;
	private String product_name;
	private int product_id;
	private String status;
	private int amount;
	private String date_and_time;
	private int quantity;
	private String merchant_email;
	private String customerId;

	public Orders() {

	}

	public Orders(int order_id, String purchase_date, String product_name, int product_id, String status, int amount,
			String date_and_time, int quantity, String merchant_email, String customerId) {
		super();
		this.order_id = order_id;
		this.purchase_date = purchase_date;
		this.product_name = product_name;
		this.product_id = product_id;
		this.status = status;
		this.amount = amount;
		this.date_and_time = date_and_time;
		this.quantity = quantity;
		this.merchant_email = merchant_email;
		this.customerId = customerId;
	}

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public String getPurchase_date() {
		return purchase_date;
	}

	public void setPurchase_date(String purchase_date) {
		this.purchase_date = purchase_date;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getDate_and_time() {
		return date_and_time;
	}

	public void setDate_and_time(String date_and_time) {
		this.date_and_time = date_and_time;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getMerchant_email() {
		return merchant_email;
	}

	public void setMerchant_email(String merchant_email) {
		this.merchant_email = merchant_email;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

}
