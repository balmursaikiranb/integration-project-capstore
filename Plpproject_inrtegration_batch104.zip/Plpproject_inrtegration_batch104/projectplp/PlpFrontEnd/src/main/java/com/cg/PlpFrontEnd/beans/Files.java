package com.cg.PlpFrontEnd.beans;

public class Files {
	
		private int id;
		private String file_directory;
		private String file_extension;
		private String file_name;
		public Files() {
		
		}
		public Files(int id, String file_directory, String file_extension, String file_name) {
			super();
			this.id = id;
			this.file_directory = file_directory;
			this.file_extension = file_extension;
			this.file_name = file_name;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getFile_directory() {
			return file_directory;
		}
		public void setFile_directory(String file_directory) {
			this.file_directory = file_directory;
		}
		public String getFile_extension() {
			return file_extension;
		}
		public void setFile_extension(String file_extension) {
			this.file_extension = file_extension;
		}
		public String getFile_name() {
			return file_name;
		}
		public void setFile_name(String file_name) {
			this.file_name = file_name;
		}  
		 

}
