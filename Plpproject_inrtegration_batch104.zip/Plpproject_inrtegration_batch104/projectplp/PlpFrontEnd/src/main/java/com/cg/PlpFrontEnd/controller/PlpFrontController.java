package com.cg.PlpFrontEnd.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.PlpFrontEnd.beans.Customer;
import com.cg.PlpFrontEnd.beans.Merchant;
import com.cg.PlpFrontEnd.beans.Product;

@RestController
public class PlpFrontController {
	@RequestMapping("/display/{id}/{product_type}/{product_category}")
	public ModelAndView show(@PathVariable int id, @PathVariable String product_type,
			@PathVariable String product_category) {

		RestTemplate rt = new RestTemplate();
		Product p = rt.getForObject("http://localhost:9999/getproducts/" + id, Product.class);
		List<Product> list = rt.getForObject(
				"http://localhost:9999/similarproducts/" + product_type + "/" + product_category, ArrayList.class);
		ModelAndView mv = new ModelAndView();
		mv.addObject("obj", p);
		mv.addObject("obj1", list);
		mv.setViewName("display");
		return mv;
	}

	/*
	 * @RequestMapping("/customers") public ModelAndView show() { RestTemplate
	 * rt=new RestTemplate(); List<Customer>
	 * list=rt.getForObject("http://localhost:9190/show", ArrayList.class);
	 * List<Customer>
	 * list=rt.getForObject("http://localhost:9190/show"?customer="+c,
	 * ArrayList.class); return new ModelAndView("display","cust",list); }
	 */
	@RequestMapping(value = "/wishlist", method = RequestMethod.GET)
	public ModelAndView getProducts(/* @PathVariable String customer_email */) {
		String customer_email = "sai@gmail.com";
		RestTemplate rt = new RestTemplate();
		/*
		 * List<Customer> list=rt.getForObject("http://localhost:9190/show",
		 * ArrayList.class);
		 */

		/*
		 * List<Product> list=rt.getForObject("http://localhost:9190/get/"?=+c,
		 * ArrayList.class);
		 */
		List<Product> list = rt.getForObject("http://localhost:9999/get/" + customer_email, ArrayList.class);
		return new ModelAndView("display1", "product", list);
	}

	@RequestMapping("/addtowishlist/{product_id}")
	public ModelAndView addProduct(@PathVariable int product_id) {
		String customer_email = "sai@gmail.com";

		RestTemplate rt = new RestTemplate();
		/*
		 * List<Customer> list=rt.getForObject("http://localhost:9190/show",
		 * ArrayList.class);
		 */

		/*
		 * List<Product> list=rt.getForObject("http://localhost:9190/get/"?=+c,
		 * ArrayList.class);
		 */
		boolean pro = rt.getForObject("http://localhost:9999/add/" + customer_email + "/" + product_id, Boolean.class);
		if (pro) {
			return new ModelAndView("addedsuccess", "wishlist", pro);
		}
		return new ModelAndView("addedfailed", "wishlist", pro);
	}

	@RequestMapping("/remove/{product_id}")
	public ModelAndView aProduct(@PathVariable int product_id) {
		String customer_email = "sai@gmail.com";

		RestTemplate rt = new RestTemplate();
		/*
		 * List<Customer> list=rt.getForObject("http://localhost:9190/show",
		 * ArrayList.class);
		 */

		/*
		 * List<Product> list=rt.getForObject("http://localhost:9190/get/"?=+c,
		 * ArrayList.class);
		 */
		boolean pro = rt.getForObject("http://localhost:9999/delete/" + customer_email + "/" + product_id,
				Boolean.class);
		if (pro) {
			return new ModelAndView("deletedsuccess", "wishlist", pro);
		}
		return new ModelAndView("deletedfailed", "wishlist", pro);
	}

	@RequestMapping("/product")
	public ModelAndView showProducts(@RequestParam String product_type, @RequestParam String product_category) {
		RestTemplate rt = new RestTemplate();
		List<Product> list = rt.getForObject(
				"http://localhost:9999/similarproducts/" + product_type + "/" + product_category, ArrayList.class);
		return new ModelAndView("display", "product", list);
	}

	@RequestMapping("/product1/{product_id}")
	public ModelAndView showProducts1(@PathVariable String product_id) {
		RestTemplate rt = new RestTemplate();
		Product list = rt.getForObject("http://localhost:9999/displayproduct/" + product_id, Product.class);
		List<Product> list1 = rt.getForObject(
				"http://localhost:9999/similarproducts/" + list.getProduct_type() + "/" + list.getProduct_category(),
				ArrayList.class);
		ModelAndView mv = new ModelAndView();
		mv.addObject("obj", list);
		mv.addObject("obj1", list1);
		mv.setViewName("display");
		return mv;
		// return new ModelAndView("displayproduct","product", list);
	}

	@RequestMapping("/index")
	public ModelAndView getProduct() {
		RestTemplate rt = new RestTemplate();
		List<Product> p = rt.getForObject("http://localhost:9999/getProducts", ArrayList.class);
		return new ModelAndView("index", "product", p);
	}

	@RequestMapping("/electronics")
	public ModelAndView getElectronics() {
		RestTemplate rt = new RestTemplate();
		List<Product> pe = rt.getForObject("http://localhost:9999/getElectronics", ArrayList.class);
		return new ModelAndView("electronics", "productelectronics", pe);
	}

	@RequestMapping("/womens")
	public ModelAndView getWomens() {
		RestTemplate rt = new RestTemplate();
		List<Product> pw = rt.getForObject("http://localhost:9999/getWomens", ArrayList.class);
		return new ModelAndView("womens", "productwomens", pw);
	}

	@RequestMapping("/mens")
	public ModelAndView getMens() {
		RestTemplate rt = new RestTemplate();
		List<Product> pm = rt.getForObject("http://localhost:9999/getMens", ArrayList.class);
		return new ModelAndView("mens", "productmens", pm);

	}

	@RequestMapping("/kids")
	public ModelAndView getKids() {
		RestTemplate rt = new RestTemplate();
		List<Product> pk = rt.getForObject("http://localhost:9999/getKids", ArrayList.class);
		return new ModelAndView("kids", "productkids", pk);

	}

	@RequestMapping("/furnitures")
	public ModelAndView getFurnitures() {
		RestTemplate rt = new RestTemplate();
		List<Product> pf = rt.getForObject("http://localhost:9999/getFurnitures", ArrayList.class);
		return new ModelAndView("furnitures", "productfurnitures", pf);

	}

	@RequestMapping("/groceries")
	public ModelAndView getGroceries() {
		RestTemplate rt = new RestTemplate();
		List<Product> pg = rt.getForObject("http://localhost:9999/getGroceries", ArrayList.class);
		return new ModelAndView("groceries", "productgroceries", pg);

	}

	@RequestMapping("/show")
	public ModelAndView getProduct1() {
		RestTemplate rt = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<Product> p = rt.getForObject("http://localhost:9999/products", ArrayList.class);
		return new ModelAndView("index", "product", p);
	}

	@RequestMapping("/low")
	public ModelAndView getAsc() {
		RestTemplate rt = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<Product> p = rt.getForObject("http://localhost:9999/LowtoHigh", ArrayList.class);
		return new ModelAndView("index", "product", p);
	}

	@RequestMapping("/high")
	public ModelAndView getDesc() {
		RestTemplate rt = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<Product> p = rt.getForObject("http://localhost:9999/HightoLow", ArrayList.class);
		return new ModelAndView("index", "product", p);
	}

	@RequestMapping("/Electronics/high")
	public ModelAndView getDescElectronics() {
		RestTemplate rt = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<Product> p = rt.getForObject("http://localhost:9999/Electronics/HightoLow", ArrayList.class);
		return new ModelAndView("electronics", "productelectronics", p);
	}

	@RequestMapping("/bestseller")
	public ModelAndView getBest() {
		RestTemplate rt = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<Product> p = rt.getForObject("http://localhost:9999/BestSeller", ArrayList.class);
		return new ModelAndView("index", "product", p);
	}

	@RequestMapping("/mostviewed")
	public ModelAndView getViewed() {
		RestTemplate rt = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<Product> p = rt.getForObject("http://localhost:9999/MostViewed", ArrayList.class);
		return new ModelAndView("index", "product", p);
	}

	@RequestMapping("/range")
	public ModelAndView getRange(@RequestParam int min, @RequestParam int max) {

		RestTemplate rt = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<Product> p = rt.getForObject("http://localhost:9999/Range?min=" + min + "&max=" + max, ArrayList.class);
		return new ModelAndView("index", "product", p);
	}

	@RequestMapping("/Search")
	public ModelAndView getBySearch(@RequestParam String pro) {
		RestTemplate rt = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<Product> p = rt.getForObject("http://localhost:9999/search?pro=" + pro, ArrayList.class);
		return new ModelAndView("index", "product", p);
	}

	@RequestMapping("/cart")
	public ModelAndView cartProducts(@RequestParam String email) {
		RestTemplate restTemplate = new RestTemplate();
		List<Product> list = restTemplate.getForObject("http://localhost:9999/cart?customerId=" + email,
				ArrayList.class);
		if (list.isEmpty()) {
			return new ModelAndView("empty");
		}
		return new ModelAndView("cart", "cartProduct", list);
	}

	@RequestMapping("/loggedin")
	public ModelAndView home() {
		RestTemplate restTemplate = new RestTemplate();
		List<Product> list = restTemplate.getForObject("http://localhost:9999", ArrayList.class);
		return new ModelAndView("index", "products", list);
	}

	@RequestMapping("/addToCart")
	public ModelAndView addCartProducts(@RequestParam String email2, @RequestParam int product) {
		RestTemplate restTemplate = new RestTemplate();
		String str = restTemplate.getForObject(
				"http://localhost:9999/addToCart?customerId=" + email2 + "&productId=" + product, String.class);
		return new ModelAndView("message", "message", str);
	}

	@RequestMapping("/removeCart")
	public ModelAndView removeCartProducts(@RequestParam String customerId, @RequestParam int productId) {
		RestTemplate restTemplate = new RestTemplate();
		String str = restTemplate.getForObject(
				"http://localhost:9999/remove?customerId=" + customerId + "&productId=" + productId, String.class);
		return new ModelAndView("message", "message", str);
	}

	@RequestMapping("/payment/card")
	public ModelAndView paymentCard(@RequestParam String email, @RequestParam String cc_num, @RequestParam String cvv,
			@RequestParam String cc_exp_mm, @RequestParam String cc_exp_yyyy) {
		RestTemplate rt = new RestTemplate();

		String str = rt.getForObject("http://localhost:9999/payment/card?email=" + email + "&cc_num=" + cc_num + "&cvv="
				+ cvv + "&cc_exp_mm=" + cc_exp_mm + "&cc_exp_yyyy=" + cc_exp_yyyy, String.class);
		if (str.equals("Successfully Credited to Admin's Wallet")) {
			
			return new ModelAndView("message", "message", str);
		} else {
			return new ModelAndView("credit", "message", str);
		}
	}

	@RequestMapping("/payment/net")
	public ModelAndView paymentNet(@RequestParam String email, @RequestParam String uname, @RequestParam String psw) {
		RestTemplate rt = new RestTemplate();
		String str = rt.getForObject(
				"http://localhost:9999/payment/net?email=" + email + "&uname=" + uname + "&psw=" + psw, String.class);
		if (str.equals("Successfully Credited to Admin's Wallet")) {
			return new ModelAndView("message", "message", str);
		} else {
			return new ModelAndView("netbanking2", "message", str);
		}
	}

	@RequestMapping("/payment/wallet")
	public ModelAndView paymentWallet(@RequestParam String email, @RequestParam String mobile,
			@RequestParam String password) {
		RestTemplate rt = new RestTemplate();
		String str = rt.getForObject(
				"http://localhost:9999/payment/wallet?email=" + email + "&mobile=" + mobile + "&password=" + password,
				String.class);
		if (str.equals("Successfully Credited to Admin's Wallet")) {

			return new ModelAndView("message", "message", str);
		} else {
			return new ModelAndView("wallet", "message", str);
		}
	}

	@RequestMapping("/customer")
	public Customer getProduct(@RequestParam String email_id, @RequestParam String password, String userName,
			String phonenumber, String address) {
		RestTemplate rt = new RestTemplate();
		Customer c = rt
				.getForObject(
						"http://localhost:9999/savecustomers?email_id=" + email_id + "&password=" + password
								+ "&userName=" + userName + "&phonenumber=" + phonenumber + "&address=" + address,
						Customer.class);
		return c;

	}

	@RequestMapping("/merchant")
	public Merchant getMerchant(@RequestParam String email_id, @RequestParam String password,
			@RequestParam String merchantName, @RequestParam String phoneNumber, @RequestParam String address,
			@RequestParam String productType) {
		RestTemplate rt1 = new RestTemplate();
		Merchant m = rt1.getForObject("http://localhost:9999/savemerchant?email_id=" + email_id + "&password="
				+ password + "&merchantName=" + merchantName + "&phoneNumber=" + phoneNumber + "&address=" + address
				+ "&productType=" + productType, Merchant.class);
		return m;
	}

	@RequestMapping("/signup")
	public ModelAndView showindex() {
		return new ModelAndView("signup");
	}

	@RequestMapping("/customer2")
	public ModelAndView showCustomerProfile() {
		RestTemplate rt = new RestTemplate();
		List<Customer> p = rt.getForObject("http://localhost:9999/show", ArrayList.class);
		return new ModelAndView("customer5", "cust", p);

	}

	@RequestMapping("/changeProfile")
	public ModelAndView updateProfile(@RequestParam String Name, @RequestParam String Email, @RequestParam String Phone,
			@RequestParam String Gender, @RequestParam String Address) {

		RestTemplate rt = new RestTemplate();
		Customer cp = rt.getForObject("http://localhost:9999/profile?Name=" + Name + "&Email=" + Email + "&Phone="
				+ Phone + "&Gender=" + Gender + "&Address=" + Address, Customer.class);
		return new ModelAndView("success5");

	}

	@RequestMapping("/feedback")
	public ModelAndView updateFeedback(@RequestParam String product, @RequestParam String feedback) {

		RestTemplate rt = new RestTemplate();
		rt.put("http://localhost:9999/feed?product=" + product + "&feedback=" + feedback, String.class);

		return new ModelAndView("display5");

	}

	@RequestMapping("/changepassword/{mail}/{current}/{newpass}")
	public ModelAndView changePassword(@PathVariable String mail, @PathVariable String current,
			@PathVariable String newpass) {
		RestTemplate rt = new RestTemplate();
		String p = rt.getForObject(
				"http://localhost:9999/change?email=" + mail + "&password=" + current + "&nPassword=" + newpass,
				String.class);
		/*
		 * attributes.addFlashAttribute("Success", "Password changed successfully");
		 * attributes.addFlashAttribute(
		 * "passwordError","You have entered wrong current password");
		 * attributes.addFlashAttribute("InvalidEmail", "Email Id doesnt exists");
		 */
		return new ModelAndView("display15", "cust", p);
	}

	@RequestMapping("/CustomerFeedback")
	public ModelAndView getProduct(@RequestParam String ProductId, @RequestParam String feedback) {
		RestTemplate rt = new RestTemplate();
		String prod = rt.getForObject("http://localhost:9999/common/" + ProductId + "/" + feedback, String.class);
		return new ModelAndView("success15", "cust", prod);
	}

	@RequestMapping("/MerchantResponse")
	public ModelAndView getProduct1(@RequestParam String ProductId, @RequestParam String response) {
		RestTemplate rt = new RestTemplate();
		String prod = rt.getForObject("http://localhost:9999/response/" + ProductId + "/" + response, String.class);
		return new ModelAndView("success25", "cust", prod);
	}

	@RequestMapping("/buynow")
	public ModelAndView sayHello() {

		RestTemplate rt = new RestTemplate();
		Customer list = rt.getForObject("http://localhost:9999/show/saikiran@gmail.com", Customer.class);
		return new ModelAndView("indexone", "cust", list);
	}

	@RequestMapping("/customers")
	public ModelAndView show() {
		RestTemplate rt = new RestTemplate();
		Customer cust = rt.getForObject("http://localhost:9999/show/saikiran@gmail.com", Customer.class);
		return new ModelAndView("displayaddress", "cust", cust);
	}

	@RequestMapping(value = "/show1")
	public ModelAndView addDetails(@RequestParam String Email, @RequestParam String Address,
			@RequestParam int orderId) {
		RestTemplate rt = new RestTemplate();
		String list = rt.getForObject("http://localhost:9999/show1?Email=" + Email + "&Address=" + Address,
				String.class);
		String str = rt.getForObject("http://localhost:9999/addToCart?customerId=" + Email + "&productId=" + orderId,
				String.class);
		if (list.equals("SuccesfullyAdded")) {
			return new ModelAndView("paymentpage1");
		} else {
			return new ModelAndView("error");
		}

	}

	/*
	 * Status
	 */

	@RequestMapping("/homepro{id}")
	public ModelAndView home(@RequestParam String id) {
		RestTemplate rt = new RestTemplate();
		Order p = rt.getForObject("http://localhost:9999/getOrderProducts?id="+id, Order.class);
		
		return new ModelAndView("OrderPlaced", "cust", p);
	}

	@RequestMapping("/Packed{id}")
	public ModelAndView packed(@RequestParam String id) {
		RestTemplate rt = new RestTemplate();
		Order p = rt.getForObject("http://localhost:9999/getOrderProducts?id=" +id, Order.class);
		return new ModelAndView("Packed", "cust", p);
	}

	@RequestMapping("/InProcess{id}")
	public ModelAndView process(@RequestParam String id) {
		RestTemplate rt = new RestTemplate();
		Order p = rt.getForObject("http://localhost:9999/getOrderProducts?id=" +id, Order.class);
		return new ModelAndView("InProcess", "cust", p);
	}

	@RequestMapping("/OutFordelivery{id}")
	public ModelAndView outForDelivery(@RequestParam String id) {
		RestTemplate rt = new RestTemplate();
		Order p = rt.getForObject("http://localhost:9999/getOrderProducts?id=" +id, Order.class);
		return new ModelAndView("OutFordelivery", "cust", p);
	}

	@RequestMapping("/Delivered{id}")
	public ModelAndView delivered(@RequestParam String id) {
		RestTemplate rt = new RestTemplate();
		Order p = rt.getForObject("http://localhost:9999/getOrderProducts?id="+id, Order.class);
		rt.getForObject("http://localhost:9898/removeOrder/" + id, Void.class);
		return new ModelAndView("Delivered", "cust", p);
	}


	@RequestMapping("/orders{customerId}")
	public ModelAndView getOrders(@RequestParam String customerId) {
		RestTemplate restTemplate = new RestTemplate();
		List<Integer> list = restTemplate.getForObject("http://localhost:9999/getOrders?customerId=" +customerId,
				ArrayList.class);
		return new ModelAndView("orders", "list", list);
	}
	
	@RequestMapping("/buy{id}")
	public ModelAndView showStatus(@RequestParam String id) {
		RestTemplate template = new RestTemplate();
		boolean result = template.getForObject("http://localhost:9999/buy?id="+id, Boolean.class);
		if (result) {
			return new ModelAndView("success");
		} else {
			return new ModelAndView("Error");
		}

	}
}
