package com.cg.PlpFrontEnd.beans;

import java.time.LocalDateTime;

public class Dispatch {

		private int dispatch_id;
		private LocalDateTime dispatch_time;
		private String location;
		private String merchant_id;
		private int product_id;
		private String product_name;
		public Dispatch() {
		
		}
		public Dispatch(int dispatch_id, LocalDateTime dispatch_time, String location, String merchant_id,
				int product_id, String product_name) {
			super();
			this.dispatch_id = dispatch_id;
			this.dispatch_time = dispatch_time;
			this.location = location;
			this.merchant_id = merchant_id;
			this.product_id = product_id;
			this.product_name = product_name;
		}
		public int getDispatch_id() {
			return dispatch_id;
		}
		public void setDispatch_id(int dispatch_id) {
			this.dispatch_id = dispatch_id;
		}
		public LocalDateTime getDispatch_time() {
			return dispatch_time;
		}
		public void setDispatch_time(LocalDateTime dispatch_time) {
			this.dispatch_time = dispatch_time;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public String getMerchant_id() {
			return merchant_id;
		}
		public void setMerchant_id(String merchant_id) {
			this.merchant_id = merchant_id;
		}
		public int getProduct_id() {
			return product_id;
		}
		public void setProduct_id(int product_id) {
			this.product_id = product_id;
		}
		public String getProduct_name() {
			return product_name;
		}
		public void setProduct_name(String product_name) {
			this.product_name = product_name;
		} 
		
		
		 

}
