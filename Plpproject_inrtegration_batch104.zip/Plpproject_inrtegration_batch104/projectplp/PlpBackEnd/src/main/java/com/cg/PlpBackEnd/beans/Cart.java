
package com.cg.PlpBackEnd.beans;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int serial_no;
	private String customer_email;
	private int product_id;
	private BigDecimal cart_amount;
	private String p_name;
	private int p_quantity;
	public Cart() {

	}
	public Cart(int serial_no, String customer_email, int product_id, BigDecimal cart_amount, String p_name,
			int p_quantity) {
		super();
		this.serial_no = serial_no;
		this.customer_email = customer_email;
		this.product_id = product_id;
		this.cart_amount = cart_amount;
		this.p_name = p_name;
		this.p_quantity = p_quantity;
	}
	public int getSerial_no() {
		return serial_no;
	}
	public void setSerial_no(int serial_no) {
		this.serial_no = serial_no;
	}
	public String getCustomer_email() {
		return customer_email;
	}
	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public BigDecimal getCart_amount() {
		return cart_amount;
	}
	public void setCart_amount(BigDecimal cart_amount) {
		this.cart_amount = cart_amount;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public int getP_quantity() {
		return p_quantity;
	}
	public void setP_quantity(int p_quantity) {
		this.p_quantity = p_quantity;
	} 
	
	
}
