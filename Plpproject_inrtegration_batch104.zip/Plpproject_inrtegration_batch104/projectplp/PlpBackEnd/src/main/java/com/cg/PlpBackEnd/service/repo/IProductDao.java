package com.cg.PlpBackEnd.service.repo;

import java.util.List;

import com.cg.PlpBackEnd.beans.Product;





public interface IProductDao {
	public List<Product> showProducts();
	List<Product> showSelectedProducts(String items);
	public List<Product> showProducts1();

	public List<Product> LowToHigh();

	public List<Product> HighToLow();

	public List<Product> BestSeller();

	public List<Product> MostViewed();

	public List<Product> Range(int min, int max);
	
	public List<Product> getBySearch(String pro);
	public List<Product> ElecHighToLow();

}