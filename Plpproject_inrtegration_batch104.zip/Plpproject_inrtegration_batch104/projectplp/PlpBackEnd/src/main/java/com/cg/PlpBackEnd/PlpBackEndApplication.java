package com.cg.PlpBackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlpBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlpBackEndApplication.class, args);
	}
}
