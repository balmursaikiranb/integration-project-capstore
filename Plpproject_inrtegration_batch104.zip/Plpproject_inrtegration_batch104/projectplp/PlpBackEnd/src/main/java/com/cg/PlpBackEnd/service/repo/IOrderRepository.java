package com.cg.PlpBackEnd.service.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.PlpBackEnd.beans.Orders;

public interface IOrderRepository extends CrudRepository<Orders, Integer>{

}
