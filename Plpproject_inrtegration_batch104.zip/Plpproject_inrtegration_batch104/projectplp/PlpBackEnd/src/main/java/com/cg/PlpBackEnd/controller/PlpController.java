package com.cg.PlpBackEnd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.PlpBackEnd.beans.CardDetails;
import com.cg.PlpBackEnd.beans.Customer;
import com.cg.PlpBackEnd.beans.Inventory;
import com.cg.PlpBackEnd.beans.Orders;
import com.cg.PlpBackEnd.beans.Product;
import com.cg.PlpBackEnd.exception.PaymentException;
import com.cg.PlpBackEnd.service.IPlpService;

@RestController
public class PlpController {

	@Autowired
	IPlpService service;

	/*
	 * @RequestMapping("/show") public List<Product> showAll() { return
	 * service.showAll(); }
	 */
	@RequestMapping("/get/{customer_email}")
	public List<Product> getProducts(@PathVariable String customer_email) {
		return service.getProducts(customer_email);
	}

	@RequestMapping("/add/{customer_email}/{product_id}")
	public boolean addProduct(@PathVariable String customer_email, @PathVariable int product_id) {
		return service.addProduct(customer_email, product_id);
	}

	@RequestMapping("/delete/{customer_email}/{product_id}")
	public boolean deleteProduct(@PathVariable String customer_email, @PathVariable int product_id) {
		return service.deleteProduct(customer_email, product_id);
	}

	@RequestMapping(value = "/getproducts/{id}")
	public Product getProductById(@PathVariable int id) {
		return service.getProductById(id);
	}

	@RequestMapping("/similarproducts/{product_type}/{product_category}")
	public List<Product> similarProducts(@PathVariable String product_type, @PathVariable String product_category) {
		return service.similarProducts(product_type, product_category);
	}

	@RequestMapping("/displayproduct/{product_id}")
	public Product s(@PathVariable int product_id) {
		return service.displayProduct(product_id);
	}

	@RequestMapping("/getProducts")
	public List<Product> getProducts() {
		return service.showProducts();
	}

	@RequestMapping("/getWomens")
	public List<Product> getWomensProducts() {
		return service.showSelectedProducts("Womens");

	}

	@RequestMapping("/getMens")
	public List<Product> getMensProducts() {
		return service.showSelectedProducts("Mens");

	}

	@RequestMapping("/getKids")
	public List<Product> getKidsProducts() {
		return service.showSelectedProducts("Kids");
	}

	@RequestMapping("/getElectronics")
	public List<Product> getElectronicsProducts() {
		return service.showSelectedProducts("Electronics");
	}

	@RequestMapping("/getFurnitures")
	public List<Product> getFurniture() {
		return service.showSelectedProducts("Furnitures");
	}

	@RequestMapping("/getGroceries")
	public List<Product> getGroceries() {
		return service.showSelectedProducts("Groceries");
	}

	@RequestMapping(value = "/products")
	public List<Product> getProducts1() {
		return service.showProducts();
	}

	@RequestMapping(value = "/LowtoHigh")
	public List<Product> getAsc() {
		return service.LowToHigh();
	}

	@RequestMapping(value = "/HightoLow")
	public List<Product> getDes() {
		return service.HighToLow();
	}

	@RequestMapping(value = "/BestSeller")
	public List<Product> getBest() {
		return service.BestSeller();
	}

	@RequestMapping(value = "/MostViewed")
	public List<Product> getView() {
		return service.MostViewed();
	}

	@RequestMapping(value = "/Range")
	public List<Product> getRange(/* @RequestParam */int min, /* @RequestParam */ int max) {
		return service.Range(min, max);
	}

	@RequestMapping(value = "/search")
	public List<Product> getBySearch(String pro) {
		return service.getBySearch(pro);
	}

	@RequestMapping(value = "/Electronics/HightoLow")
	public List<Product> getDesElec() {
		return service.ElecHighToLow();
	}

	@RequestMapping("/cart")
	public List<Product> cartProducts(@RequestParam String customerId) {
		List<Product> list = service.cartProducts(customerId);
		return list;
	}

	@RequestMapping(value = "/addToCart{customerId}{productId}")
	public String addCart(@RequestParam String customerId, @RequestParam int productId) {

		service.addCart(customerId, productId);
		return "Added";
	}

	@RequestMapping(value = "/remove{customerId}{productId}")
	public String remove(@RequestParam String customerId, @RequestParam int productId) {
		service.remove(customerId, productId);
		return "Removed";
	}

	@RequestMapping(value = "/payment/card{email}{cc_num}{cvv}{cc_exp_mm}{cc_exp_yyyy}")
	public String paymentCard(@RequestParam String email, @RequestParam String cc_num, @RequestParam String cvv,
			@RequestParam String cc_exp_mm, @RequestParam String cc_exp_yyyy) {
		int adminId = 1;
		CardDetails cardDetails = new CardDetails();
		cardDetails.setCardNumber(cc_num);
		cardDetails.setCardMonth(cc_exp_mm);
		cardDetails.setCardYear(cc_exp_yyyy);
		cardDetails.setCVVNumber(cvv);

		try {
			if (service.validation(cardDetails)) {
				service.payment(email, adminId);
				return "Successfully Credited to Admin's Wallet";
			} else {
				return "Not Successfully Credited to Admin's Wallet";
			}
		} catch (PaymentException e) {
			return e.getMessage();
		}

	}

	@RequestMapping(value = "/payment/net{email}{uname}{psw}")
	public String paymentNet(@RequestParam String email, @RequestParam String uname, @RequestParam String psw) {
		int adminId = 1;
		try {
			if (service.validate(uname, psw)) {
				service.payment(email, adminId);
				return "Successfully Credited to Admin's Wallet";
			} else {
				return "Not Successfully Credited to Admin's Wallet";
			}
		} catch (PaymentException e) {
			return e.getMessage();
		}
	}

	@RequestMapping(value = "/payment/wallet{email}{mobile}{password}")
	public String paymentWallet(@RequestParam String email, @RequestParam String mobile,
			@RequestParam String password) {
		int adminId = 1;
		try {
			if (service.validateWallet(mobile, password)) {
				service.payment(email, adminId);
				return "Successfully Credited to Admin's Wallet";
			} else {
				return "Not Successfully Credited to Admin's Wallet";
			}
		} catch (PaymentException e) {
			return e.getMessage();
		}
	}

	@RequestMapping("/show")
	public List<Customer> showAll() {
		return service.showAll2();
	}

	@RequestMapping(value = "/profile{Name}{Email}{Phone}{Gender}{Address}")
	void updateProfile(@RequestParam String Name, @RequestParam String Email, @RequestParam String Phone,
			@RequestParam String Gender, @RequestParam String Address) {

		service.updateProfile(Name, Email, Phone, Gender, Address);
		System.out.println("Profile Added Successfully");

	}

	@RequestMapping("/feed")
	public String updateFeedback(@RequestParam int product, @RequestParam String feedback) {
		service.updateProduct(product, feedback);
		return service.updateFeedback(product, feedback);

	}

	@RequestMapping("/change")
	public String changePassword(@RequestParam String email, @RequestParam String password,
			@RequestParam String nPassword) {
		return service.changePassword(email, password, nPassword);
	}

	@RequestMapping("/common/{id}/{feedback}")
	public String addFeedback(@PathVariable int id, @PathVariable String feedback) {
		String add = service.addFeedback(id, feedback);
		if (add.equals("Feedbackadded")) {
			return "Your feedback added successfully!!";
		} else {
			return "Your  feedback unsuccessfull!!";
		}
	}

	@RequestMapping("/response/{id}/{response}")
	public String addResponse(@PathVariable int id, @PathVariable String response) {
		String add = service.addResponse(id, response);
		if (add.equals("Responseadded")) {
			return "Your response added successfully!!";
		} else {
			return "Your response unsent";
		}

	}

	@RequestMapping(value = "/savecustomers{email_id}{password}{userName}{phonenumber}{address}")
	public void saveCustomer(@RequestParam String email_id, @RequestParam String password,
			@RequestParam String userName, @RequestParam String phonenumber, @RequestParam String address) {
		String psw1 = service.encrypt(password);
		/*
		 * String psw2=service.encrypt(psw_repeat); service.signUp(email, psw1, psw2);
		 */
		service.saveCustomer(email_id, psw1, userName, phonenumber, address);
		System.out.println("Registered Successfully");

	}

	@RequestMapping(value = "/savemerchant{email_id}{password}{merchantName}{phoneNumber}{address}{producttype}")
	public void saveMerchant(@RequestParam String email_id, @RequestParam String password,
			@RequestParam String merchantName, @RequestParam String phoneNumber, @RequestParam String address,
			@RequestParam String productType) {
		service.saveMerchant(email_id, password, merchantName, phoneNumber, address, productType);
		System.out.println("Registered Successfully");
	}

	@RequestMapping(value = "/show1")
	public String addDetails(@RequestParam String Email, @RequestParam String Address) {

		service.addDetails(Email, Address);
		return "SuccesfullyAdded";
	}

	@RequestMapping(value = "/show/{email}")
	public Customer showAll(@PathVariable String email) {

		return service.showAll(email);
	}

	@RequestMapping("/getOrderProducts{id}")
	public Orders getOrderProductById(@RequestParam int id) {
		return service.getorderById(id);

	}

	@RequestMapping("/getOrders{customerId}")
	public List<Integer> getOrderById(@RequestParam String customerId) {
		return service.getordersById(customerId);
	}

	@RequestMapping("/buy{id}")
	public boolean showStatus(@RequestParam int id) {
		return service.showStatus(id);
	}

	@RequestMapping("/inventory")
	public List<Inventory> showInventory() {
		List<Inventory> list = service.showAllProducts();
		return list;
	}

	@RequestMapping("/removeOrder/{id}")
	public void removeOrder(@PathVariable int id) {

		service.removeOrder(id);
	}
}
