package com.cg.PlpBackEnd.service.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.PlpBackEnd.beans.Product;





@Repository
public class ProductDaoImpl implements IProductDao {

	@Autowired
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Product> showProducts() {
		List<Product> list = new ArrayList<>();
		Query q = entityManager.createQuery("from Product");
		list = q.getResultList();
		return list;
	}

public List<Product> showSelectedProducts(@PathVariable String items) {
		
		List<Product> list =new ArrayList<>();
		Query q2=entityManager.createQuery("from Product where product_category='"+items+"'");
		list =q2.getResultList();
		return list;
	
}





public List<Product> showProducts1() {

	List<Product> list = new ArrayList<>();
	Query q = entityManager.createQuery("from Product");
	list = q.getResultList();
	return list;
}

public List<Product> LowToHigh() {

	List<Product> list = new ArrayList<>();
	Query q = entityManager.createQuery("from Product ORDER BY product_price ASC");
	list = q.getResultList();
	return list;
}

public List<Product> HighToLow() {
	List<Product> list = new ArrayList<>();
	Query q = entityManager.createQuery("from Product ORDER BY product_price DESC");
	list = q.getResultList();
	return list;
}

public List<Product> BestSeller() {

	List<Product> list = new ArrayList<>();
	Query q = entityManager.createQuery("from Product ORDER BY product_soldCount DESC");
	list = q.getResultList();
	return list;
}

public List<Product> MostViewed() {

	List<Product> list = new ArrayList<>();
	Query q = entityManager.createQuery("from Product ORDER BY product_viewCount DESC");
	list = q.getResultList();
	return list;
}

public List<Product> Range(int min, int max) {

	List<Product> list = new ArrayList<>();
	Query q = entityManager.createQuery("FROM Product WHERE product_price BETWEEN '" + min + "' AND '" + max + "'");
	list = q.getResultList();
	return list;
}

@Override
public List<Product> getBySearch(String pro) {
	List<Product> list = new ArrayList<>();
	Query query = entityManager.createQuery("FROM Product WHERE product_type= '"+ pro +"'");
	list = query.getResultList();
	return list;
}

@Override
public List<Product> ElecHighToLow() {
	List<Product> list = new ArrayList<>();
	Query q = entityManager.createQuery("from Product where product_category='Electronics' ORDER BY product_price  DESC");
	list = q.getResultList();
	return list;
}

}
