package com.cg.PlpBackEnd.service.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.PlpBackEnd.beans.WishList;




@Repository
public interface IWishListRepo extends CrudRepository<WishList, Integer>{

}
