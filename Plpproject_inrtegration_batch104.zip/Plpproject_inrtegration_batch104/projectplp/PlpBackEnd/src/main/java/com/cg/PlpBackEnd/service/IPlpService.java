package com.cg.PlpBackEnd.service;

import java.util.List;
import java.util.Optional;



import com.cg.PlpBackEnd.beans.CardDetails;
import com.cg.PlpBackEnd.beans.Customer;
import com.cg.PlpBackEnd.beans.Inventory;
import com.cg.PlpBackEnd.beans.Orders;
import com.cg.PlpBackEnd.beans.Product;
import com.cg.PlpBackEnd.exception.PaymentException;





public interface IPlpService {

	public List<Product> showAll1();
	public List<Product> getProducts(String customer_email);
	public boolean addProduct(String customer_email,int product_id);
	public boolean deleteProduct(String customer_email,int product_id);
	public Product getProductById(int product_id);
	public List<Product> similarProducts(String product_type, String product_category);
	public Product displayProduct(int product_id);
 public List<Product> showProducts();
	 
	 public List<Product> showSelectedProducts(String items);
	 
		public List<Product> showProducts1();

		public List<Product> LowToHigh();

		public List<Product> HighToLow();

		public List<Product> BestSeller();

		public List<Product> MostViewed();

		public List<Product> Range(int min, int max);
		
		public List<Product> getBySearch(String pro);
		public List<Product> ElecHighToLow();
		
		
		
		
		public List<Customer> showAll();

		public List<Product> cartProducts(String customerId);

		public void remove(String customerId, int productId);

		void addCart(String customerId, int productId);

		void payment(String email, int adminId);

		public boolean validation(CardDetails cardDetails) throws PaymentException;

		public boolean validate(String uname, String psw) throws PaymentException;

		public boolean validateWallet(String mobile, String password) throws PaymentException;

		public List<Product> products();
		
		
		
		
		
		
		public List<Customer> showAll2();

		public void updateProfile(String name, String email, String phone, String gender, String address);

		public void updateProduct(int product, String feedback);

		public String updateFeedback(int product, String feedback);

		public String changePassword(String email, String password, String nPassword);

		public String addFeedback(int id, String feedback);

		public String addResponse(int pid, String response);
		
		
		
		
		
		
		public void saveMerchant(String email_id, String password,String merchantName, String phoneNumber, String address, String product_type);

				public void saveCustomer(String email_id, String password, String userName, String phonenumber, String address);

	
		
		public Optional<Customer> getCustomer(String email);
		
		
		public String encrypt(String password);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		public Customer showAll(String email);
		public String addDetails(String email, String address);
		
		
		
		
		
		
		
		
		
		
		
		public Orders getorderById(int id);
		public boolean showStatus(int id);
		public List<Integer> getordersById(String customerId);
		public List<Inventory> showAllProducts();
		public void removeOrder(int id);

}
