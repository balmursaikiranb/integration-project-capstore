package com.cg.PlpBackEnd.exception;

public interface IPaymentException {

	String cardNumberException = "Enter Valid Card Number ";
	String CVVException = "Enter Valid CVV";
	String ExpiryDateException = "Enter Valid ExpiryYear";
	
	String userNameException="Enter Valid Username ";
	String PasswordException="Enter valid Password";
	String mobileException = "Enter valid mobile number";
}
