package com.cg.PlpBackEnd.service.repo;

public interface IPlpRepo {

}
