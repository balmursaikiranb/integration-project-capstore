package com.cg.PlpBackEnd.service.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.PlpBackEnd.beans.Customer;



@Repository
public interface ICustomerProfileRepo extends CrudRepository<Customer, String> {

}
