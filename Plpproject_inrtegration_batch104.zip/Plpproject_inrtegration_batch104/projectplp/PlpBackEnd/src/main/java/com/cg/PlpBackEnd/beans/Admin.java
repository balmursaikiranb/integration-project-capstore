package com.cg.PlpBackEnd.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Admin {

	@Id
	private int admin_id; 
	private String  admin_password;
	private double admin_wallet;  
	private String  admin_phone;
	private String    admin_name ;
	 private int  product_id;
	 private String  customer_feedback;
	 private String  merchant_email;
	 private String   merchant_response;
	public Admin() {

	}
	public Admin(int admin_id, String admin_password, double admin_wallet, String admin_phone, String admin_name,
			int product_id, String customer_feedback, String merchant_email, String merchant_response) {
		super();
		this.admin_id = admin_id;
		this.admin_password = admin_password;
		this.admin_wallet = admin_wallet;
		this.admin_phone = admin_phone;
		this.admin_name = admin_name;
		this.product_id = product_id;
		this.customer_feedback = customer_feedback;
		this.merchant_email = merchant_email;
		this.merchant_response = merchant_response;
	}
	public int getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(int admin_id) {
		this.admin_id = admin_id;
	}
	public String getAdmin_password() {
		return admin_password;
	}
	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	public double getAdmin_wallet() {
		return admin_wallet;
	}
	public void setAdmin_wallet(double admin_wallet) {
		this.admin_wallet = admin_wallet;
	}
	public String getAdmin_phone() {
		return admin_phone;
	}
	public void setAdmin_phone(String admin_phone) {
		this.admin_phone = admin_phone;
	}
	public String getAdmin_name() {
		return admin_name;
	}
	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getCustomer_feedback() {
		return customer_feedback;
	}
	public void setCustomer_feedback(String customer_feedback) {
		this.customer_feedback = customer_feedback;
	}
	public String getMerchant_email() {
		return merchant_email;
	}
	public void setMerchant_email(String merchant_email) {
		this.merchant_email = merchant_email;
	}
	public String getMerchant_response() {
		return merchant_response;
	}
	public void setMerchant_response(String merchant_response) {
		this.merchant_response = merchant_response;
	}
	
	 
}
