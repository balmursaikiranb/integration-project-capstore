package com.cg.PlpBackEnd.service.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.PlpBackEnd.beans.Admin;





public interface IAdminRepository extends CrudRepository<Admin, Integer>{

}
