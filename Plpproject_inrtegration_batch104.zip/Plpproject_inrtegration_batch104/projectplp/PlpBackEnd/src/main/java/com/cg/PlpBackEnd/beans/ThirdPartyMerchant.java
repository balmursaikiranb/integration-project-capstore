package com.cg.PlpBackEnd.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ThirdPartyMerchant {


	@Id
	private String  third_party_merchant_email ;
		private String  third_party_merchant_category ;
		private String third_party_merchant_ifsc_code;
		private String third_party_merchant_location  ;
		private String third_party_merchant_mobile ;
		private String third_party_merchant_name ;
		private String  third_party_merchant_account_number ;
		public ThirdPartyMerchant() {
	
		}
		public ThirdPartyMerchant(String third_party_merchant_email, String third_party_merchant_category,
				String third_party_merchant_ifsc_code, String third_party_merchant_location,
				String third_party_merchant_mobile, String third_party_merchant_name,
				String third_party_merchant_account_number) {
			super();
			this.third_party_merchant_email = third_party_merchant_email;
			this.third_party_merchant_category = third_party_merchant_category;
			this.third_party_merchant_ifsc_code = third_party_merchant_ifsc_code;
			this.third_party_merchant_location = third_party_merchant_location;
			this.third_party_merchant_mobile = third_party_merchant_mobile;
			this.third_party_merchant_name = third_party_merchant_name;
			this.third_party_merchant_account_number = third_party_merchant_account_number;
		}
		public String getThird_party_merchant_email() {
			return third_party_merchant_email;
		}
		public void setThird_party_merchant_email(String third_party_merchant_email) {
			this.third_party_merchant_email = third_party_merchant_email;
		}
		public String getThird_party_merchant_category() {
			return third_party_merchant_category;
		}
		public void setThird_party_merchant_category(String third_party_merchant_category) {
			this.third_party_merchant_category = third_party_merchant_category;
		}
		public String getThird_party_merchant_ifsc_code() {
			return third_party_merchant_ifsc_code;
		}
		public void setThird_party_merchant_ifsc_code(String third_party_merchant_ifsc_code) {
			this.third_party_merchant_ifsc_code = third_party_merchant_ifsc_code;
		}
		public String getThird_party_merchant_location() {
			return third_party_merchant_location;
		}
		public void setThird_party_merchant_location(String third_party_merchant_location) {
			this.third_party_merchant_location = third_party_merchant_location;
		}
		public String getThird_party_merchant_mobile() {
			return third_party_merchant_mobile;
		}
		public void setThird_party_merchant_mobile(String third_party_merchant_mobile) {
			this.third_party_merchant_mobile = third_party_merchant_mobile;
		}
		public String getThird_party_merchant_name() {
			return third_party_merchant_name;
		}
		public void setThird_party_merchant_name(String third_party_merchant_name) {
			this.third_party_merchant_name = third_party_merchant_name;
		}
		public String getThird_party_merchant_account_number() {
			return third_party_merchant_account_number;
		}
		public void setThird_party_merchant_account_number(String third_party_merchant_account_number) {
			this.third_party_merchant_account_number = third_party_merchant_account_number;
		} 
		
		
}
