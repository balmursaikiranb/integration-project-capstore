package com.cg.PlpBackEnd.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.PlpBackEnd.beans.Admin;
import com.cg.PlpBackEnd.beans.CardDetails;
import com.cg.PlpBackEnd.beans.Cart;
import com.cg.PlpBackEnd.beans.CommonFeedback;
import com.cg.PlpBackEnd.beans.Customer;
import com.cg.PlpBackEnd.beans.Feedback;
import com.cg.PlpBackEnd.beans.Inventory;
import com.cg.PlpBackEnd.beans.Merchant;
import com.cg.PlpBackEnd.beans.Orders;
import com.cg.PlpBackEnd.beans.Pdetails;
import com.cg.PlpBackEnd.beans.Product;
import com.cg.PlpBackEnd.beans.WishList;
import com.cg.PlpBackEnd.exception.IPaymentException;
import com.cg.PlpBackEnd.exception.PaymentException;
import com.cg.PlpBackEnd.service.repo.IAdminRepo;
import com.cg.PlpBackEnd.service.repo.ICartRepo;
import com.cg.PlpBackEnd.service.repo.ICustomerProfileRepo;
import com.cg.PlpBackEnd.service.repo.ICustomerRepo;
import com.cg.PlpBackEnd.service.repo.IFeedbackRepo;
import com.cg.PlpBackEnd.service.repo.IFeedbackRepository;
import com.cg.PlpBackEnd.service.repo.IInventoryRepository;
import com.cg.PlpBackEnd.service.repo.IMerchantRepository;
import com.cg.PlpBackEnd.service.repo.IOrderRepository;

import com.cg.PlpBackEnd.service.repo.IProductDao;
import com.cg.PlpBackEnd.service.repo.IProductRepo;
import com.cg.PlpBackEnd.service.repo.IWishListRepo;

@Service
public class PlpServiceImpl implements IPlpService {

	@Autowired
	ICustomerProfileRepo custrepo;
	@Autowired
	IProductDao repo;
	@Autowired
	IProductRepo repo1;
	@Autowired
	IWishListRepo repo2;

	@Autowired
	ICustomerRepo repo3;
	@Autowired
	ICartRepo cartRepo;

	@Autowired
	IAdminRepo adminRepo;

	@Autowired
	IProductRepo prepo;

	@Autowired
	IFeedbackRepo frepo;

	@Autowired
	IFeedbackRepository feedbackRepo;
	@Autowired
	IMerchantRepository merchantRepo;

	@Autowired
	IInventoryRepository inventoryRepo;
	@Autowired
	IOrderRepository order;
	/*@Autowired
	IPdetailsRepo pdetails;*/

	@Override
	public List<Product> showAll1() {
		List<Product> list = new ArrayList<>();
		/*
		 * repo.createQuery("Select product_id from product where customer_email=''");
		 */
		repo1.findAll().forEach(list::add);

		return list;
	}

	@Override
	public List<Product> getProducts(String customer_email) {
		List<WishList> list = new ArrayList<>();
		List<Product> customer_wishlist = new ArrayList<>();
		repo2.findAll().forEach(list::add);
		for (WishList wishList : list) {
			if (wishList.getCustomer_email().equals(customer_email)) {
				// customer_wishlist.add(wishList);
				int product_id = wishList.getProduct_id();

				customer_wishlist.add(repo1.findById(product_id).get());
			}
		}
		return customer_wishlist;
		/* return repository.getProducts(customer_email); */
	}

	@Override
	public boolean addProduct(String customer_email, int product_id) {
		List<WishList> list = new ArrayList<>();
		repo2.findAll().forEach(list::add);
		for (WishList wishList : list) {
			if (wishList.getCustomer_email().equals(customer_email) && (wishList.getProduct_id() == product_id)) {
				return false;
			}
		}
		WishList wl = new WishList();
		wl.setCustomer_email(customer_email);
		wl.setProduct_id(product_id);
		repo2.save(wl);
		return true;
	}

	@Override
	public boolean deleteProduct(String customer_email, int product_id) {
		List<WishList> list = new ArrayList<>();
		repo2.findAll().forEach(list::add);
		for (WishList wishList : list) {
			if ((wishList.getCustomer_email().equals(customer_email)) && (wishList.getProduct_id() == product_id)) {
				repo2.delete(wishList);
				return true;
			}
		}
		return false;
	}

	@Override
	public Product getProductById(int product_id) {

		Product p = repo1.findById(product_id).get();
		return p;
	}

	@Override
	public List<Product> similarProducts(String product_type, String product_category) {
		List<Product> prodlist = new ArrayList<>();
		repo1.findAll().forEach(prodlist::add);
		/*
		 * for (Product product : prodlist) { Query q1 =
		 * Entity.createQuery("from Product where category='" +product_category+ "'");
		 * if((product.getProduct_type().equals(product_type)) &&
		 * (product.getProduct_category().equals(product_category))){ List<Product>
		 * similar = q1.getResultList();
		 */
		List<Product> similar = new ArrayList<>();
		for (Product product : prodlist) {
			if (product.getProduct_type().equals(product_type)
					&& (product.getProduct_category().equals(product_category))) {
				similar.add(product);
			}
		}
		return similar;
	}

	@Override
	public Product displayProduct(int product_id) {

		return repo1.findById(product_id).get();
	}

	@Override
	public List<Product> showProducts1() {
		return repo.showProducts();
	}

	@Override
	public List<Product> showSelectedProducts(String items) {
		return repo.showSelectedProducts(items);
	}

	@Override
	public List<Product> showProducts() {

		return repo.showProducts();
	}

	@Override
	public List<Product> LowToHigh() {

		return repo.LowToHigh();
	}

	@Override
	public List<Product> HighToLow() {

		return repo.HighToLow();
	}

	public List<Product> BestSeller() {
		return repo.BestSeller();
	}

	public List<Product> MostViewed() {
		return repo.MostViewed();
	}

	public List<Product> Range(int min, int max) {
		return repo.Range(min, max);
	}

	@Override
	public List<Product> getBySearch(String pro) {
		return repo.getBySearch(pro);
	}

	@Override
	public List<Product> ElecHighToLow() {
		return repo.ElecHighToLow();
	}

	@Override
	public List<Customer> showAll() {
		List<Customer> list = new ArrayList<>();
		repo3.findAll().forEach(list::add);
		return list;
	}

	@Override
	public List<Product> cartProducts(String customerId) {

		List<Cart> cartList = new ArrayList<>();
		List<Product> list = new ArrayList<>();
		cartRepo.findAll().forEach(cartList::add);

		for (Cart cart : cartList) {
			String cusId = cart.getCustomer_email();
			int prodId = cart.getProduct_id();
			if (cusId.equals(customerId)) {
				Product product = repo1.findById(prodId).get();
				list.add(product);
			}
		}
		return list;
	}

	@Override
	public void addCart(String customerId, int productId) {

		Cart cart = new Cart();
		cart.setCustomer_email(customerId);
		cart.setProduct_id(productId);
		cartRepo.save(cart);
	}

	@Override
	public void remove(String customerId, int productId) {
		List<Cart> cartList = new ArrayList<>();
		cartRepo.findAll().forEach(cartList::add);
		for (Cart cart : cartList) {
			String custId = cart.getCustomer_email();
			int prodId = cart.getProduct_id();
			int id = cart.getSerial_no();
			if (prodId == productId && custId.equals(customerId)) {
				cartRepo.deleteById(id);
				break;
			}
		}
	}

	public boolean validate(String uname, String psw) throws PaymentException {

		boolean result = false;

		Pattern pattern = Pattern.compile("[A-Za-z0-9]{8,}");
		Matcher matcher = pattern.matcher(uname);
		if (!(matcher.matches())) {
			throw new PaymentException(IPaymentException.userNameException);
		} else {
			result = true;
		}
		Pattern patternPassword = Pattern.compile("[A-Za-z0-9@$#!^&%*]{8,}");
		Matcher matcherPassword = patternPassword.matcher(psw);
		if (!(matcherPassword.matches())) {
			throw new PaymentException(IPaymentException.PasswordException);
		} else {
			result = true;
		}
		return result;
	}

	public boolean validation(CardDetails cardDetails) throws PaymentException {

		boolean result = false;
		Pattern pattern = Pattern.compile("[0-9]{16}");
		Matcher matcher = pattern.matcher(cardDetails.getCardNumber());
		if (!(matcher.matches())) {
			result = false;
			throw new PaymentException(IPaymentException.cardNumberException);
		} else {
			result = true;
		}
		Pattern patternCvv = Pattern.compile("[0-9]{3,4}");
		Matcher matcherCvv = patternCvv.matcher(cardDetails.getCVVNumber());
		if (!(matcherCvv.matches())) {
			result = false;
			throw new PaymentException(IPaymentException.CVVException);
		} else {
			result = true;
		}

		LocalDate today = LocalDate.now();
		int month = today.getMonth().getValue();
		int year = today.getYear();
		int mm = Integer.parseInt(cardDetails.getCardMonth());
		int yyyy = Integer.parseInt(cardDetails.getCardYear());
		if (yyyy > year) {
			result = true;
		} else if ((yyyy == year) && (mm > month)) {
			result = true;
		} else {
			result = false;
			throw new PaymentException(IPaymentException.ExpiryDateException);
		}
		return result;
	}

	@Override
	public void payment(String email, int adminId) {

		List<Product> products = cartProducts(email);
		double amount = 0;
		for (Product product : products) {
			amount += product.getProduct_price();
			remove(email, product.getProduct_id());
		}

		Admin admin = adminRepo.findById(adminId).get();
		admin.setAdmin_wallet(admin.getAdmin_wallet() + amount);
		adminRepo.save(admin);
	}

	@Override
	public boolean validateWallet(String mobile, String password) throws PaymentException {
		boolean result = false;

		Pattern pattern = Pattern.compile("[0-9]{10}");
		Matcher matcher = pattern.matcher(mobile);
		if (!(matcher.matches())) {
			throw new PaymentException(IPaymentException.mobileException);
		} else {

			result = true;
		}

		Pattern patternPassword = Pattern.compile("[A-Za-z0-9@$#!^&%*]{8,}");
		Matcher matcherPassword = patternPassword.matcher(password);
		if (!(matcherPassword.matches())) {
			throw new PaymentException(IPaymentException.PasswordException);
		} else {
			result = true;
		}
		return result;
	}

	@Override
	public List<Product> products() {

		List<Product> list = new ArrayList<>();
		repo1.findAll().forEach(list::add);
		return list;
	}

	Admin admin = new Admin();
	CommonFeedback fb = new CommonFeedback();
	Merchant merchant = new Merchant();

	@Override
	public List<Customer> showAll2() {

		List<Customer> list = new ArrayList<>();
		custrepo.findAll().forEach(list::add);
		return list;

	}

	@Override
	public void updateProfile(String name, String email, String phone, String gender, String address) {
		Customer c = custrepo.findById(email).get();
		c.setUser_name(name);
		c.setPhonenumber(phone);
		c.setCustomer_gender(gender);
		c.setAddress(address);
		custrepo.save(c);

	}

	@Override
	public void updateProduct(int id, String feedback) {

		Product product = new Product();

		if (id == 101) {
			product.setProduct_id(id);
			product.setCompany_name("Iphone x");
			product.setProduct_price(100000);
			product.setProduct_description("With Iphine X the device is the display and All new 5.8-inchscreen");
			prepo.save(product);

		} else if (id == 102) {
			product.setProduct_id(id);
			product.setCompany_name("Nike Running Shoes");
			product.setProduct_price(5000);
			product.setProduct_description("This down shifter running shoes comes in Navy blue and white color");
			prepo.save(product);

		} else if (id == 103) {
			product.setProduct_id(id);
			product.setCompany_name("Parker pen");
			product.setProduct_price(1500);
			product.setProduct_description("Premium quality. Special edition pen");
			prepo.save(product);

		} else if (id == 104) {
			product.setProduct_id(id);
			product.setCompany_name("Mi Note5pro");
			product.setProduct_price(18000);
			product.setProduct_description("The 5'7 inch display with rounded corners");
			prepo.save(product);

		} else if (id == 105) {
			product.setProduct_id(id);
			product.setCompany_name("Samsung J7");
			product.setProduct_price(8000);
			product.setProduct_description("High speed browsing and 4g enabled");
			prepo.save(product);

		} else if (id == 106) {
			product.setProduct_id(id);
			product.setCompany_name("Shoetopia slippers");
			product.setProduct_price(400);
			product.setProduct_description("Attractive and provide comfort to feet");
			prepo.save(product);

		} else if (id == 107) {
			product.setProduct_id(id);
			product.setCompany_name("Flying machine jeans");
			product.setProduct_price(2000);
			product.setProduct_description("High rise and skinny fit");
			prepo.save(product);

		} else if (id == 108) {
			product.setProduct_id(id);
			product.setCompany_name("UCB shirt");
			product.setProduct_price(1600);
			product.setProduct_description("100% cotton, machine wash");
			prepo.save(product);

		}
	}

	@Override
	public String updateFeedback(int id, String feedback) {
		Feedback feed = new Feedback();
		if (id != 0) {
			feed.setFeedbackid(id);
			feed.setFeedback(feedback);
			frepo.save(feed);
			return "Product added succesfully !!!";
		} else {
			return "Product not present.. Feedback cannot be added!!!!";
		}

	}

	@Override
	public String changePassword(String email, String password, String nPassword) {
		if (custrepo.existsById(email)) {

			Customer existUser = custrepo.findById(email).get();
			if (password.equals(existUser.getPassword())) {
				existUser.setPassword(nPassword);
				custrepo.save(existUser);
				return "Password changed succesfully";

			}
			return "You have entered wrong current password";
		}
		return "Email Id doesnt exists";

	}

	@Override
	public String addFeedback(int id, String feedback) {
		List<Merchant> list = new ArrayList<>();
		merchantRepo.findAll().forEach(list::add);
		admin.setProduct_id(id);
		admin.setCustomer_feedback(feedback);
		fb.setProduct_id(id);
		fb.setCustomer_feedback(feedback);
		for (Merchant merchant : list) {
			if (merchant.getProduct_id() == id) {
				merchant.setProduct_id(id);
				merchant.setCustomer_feedback(feedback);
				feedbackRepo.save(fb);
				adminRepo.save(admin);
				merchantRepo.save(merchant);

				return "Feedbackadded";
			}

		}
		return feedback;
	}

	@Override
	public String addResponse(int pid, String response) {
		List<Merchant> list = new ArrayList<>();
		merchantRepo.findAll().forEach(list::add);
		admin.setProduct_id(pid);
		admin.setMerchant_response(response);
		fb.setProduct_id(pid);
		fb.setMerchant_response(response);

		for (Merchant merchant : list) {
			if (merchant.getProduct_id() == pid) {
				merchant.setProduct_id(pid);
				merchant.setMerchant_response(response);
				feedbackRepo.save(fb);
				adminRepo.save(admin);
				merchantRepo.save(merchant);
				return "Responseadded";
			}

		}
		return response;
	}

	@Override
	public void saveCustomer(String email_id, String password, String userName, String phonenumber, String address) {
		Customer c = new Customer();
		Pdetails p=new Pdetails();
		c.setCustomer_email(email_id);
		c.setPassword(password);
		c.setUser_name(userName);
		c.setPhonenumber(phonenumber);
		c.setAddress(address);

		c.setCustomer_gender("male");
		/*c.setCustomer_refcode(000);
		c.setOrder_id(0);
		c.setCode(0);*/
	/*p.setC_email(email_id);

		p.setC_name(userName);
		p.setC_phone_no(Integer.parseInt(phonenumber));
		p.setC_address(address);

		p.setC_gender("male");
		p.setC_age(21);
		pdetails.save(p);*/
		custrepo.save(c);
	}

	@Override
	public void saveMerchant(String email_id, String password, String merchantName, String phoneNumber, String address,
			String product_type) {
		Merchant m = new Merchant();
		m.setMerchant_email(email_id);
		m.setPassword(password);
		m.setMerchant_name(merchantName);
		m.setMerchant_mobile(phoneNumber);
		m.setAddress(address);
		m.setProducttype(product_type);
		merchantRepo.save(m);

	}

	@Override
	public Optional<Customer> getCustomer(String email) {
		return custrepo.findById(email);
	}

	@Override
	public String encrypt(String password) {

		StringBuilder sb = new StringBuilder();
		for (char c : password.toCharArray()) {
			int x = (int) c;
			x = x + 5;
			char a = (char) x;

			sb.append(a);
			sb.append('$');
		}

		return sb.toString();
	}

	@Override
	public Customer showAll(String email) {
		// repo.save(details);
		Customer list = custrepo.findById(email).get();

		return list;

	}

	@Override
	public String addDetails(String email, String address) {
		Customer s1 = custrepo.findById(email).get();
		s1.setAddress(address);
		custrepo.save(s1);
		return "Addedsuccessfully";
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public Orders getorderById(int id) {
		return order.findById(id).get();
	}

	@Override
	public boolean showStatus(int id) {
		Inventory inventory = inventoryRepo.findById(id).get();
		if (inventory.getProduct_count() > 0) {
			inventory.setProduct_count(inventory.getProduct_count() - 1);
			inventoryRepo.save(inventory);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public List<Integer> getordersById(String customerId) {
		List<Orders> orders = new ArrayList<>();
		List<Integer> list = new ArrayList<>();

		order.findAll().forEach(orders::add);
		for (Orders orderTable : orders) {
			if (orderTable.getCustomerId().equals(customerId)) {
				list.add(orderTable.getOrder_id());
			}
		}
		return list;

	}

	@Override
	public List<Inventory> showAllProducts() {
		List<Inventory> list = new ArrayList<>();
		inventoryRepo.findAll().forEach(list::add);
		return list;
	}

	@Override
	public void removeOrder(int id) {
		order.deleteById(id);
	}

}