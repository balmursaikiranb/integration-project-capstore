package com.cg.PlpBackEnd.beans;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Coupon {
	@Id
	private String coupon_id;       
	private  LocalDate validity;       
	private String customer_email;
	private int discount ;    
	private String merchant_email; 
	private String product_type;
	public Coupon() {
	
	}
	public Coupon(String coupon_id, LocalDate validity, String customer_email, int discount, String merchant_email,
			String product_type) {
		super();
		this.coupon_id = coupon_id;
		this.validity = validity;
		this.customer_email = customer_email;
		this.discount = discount;
		this.merchant_email = merchant_email;
		this.product_type = product_type;
	}
	public String getCoupon_id() {
		return coupon_id;
	}
	public void setCoupon_id(String coupon_id) {
		this.coupon_id = coupon_id;
	}
	public LocalDate getValidity() {
		return validity;
	}
	public void setValidity(LocalDate validity) {
		this.validity = validity;
	}
	public String getCustomer_email() {
		return customer_email;
	}
	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public String getMerchant_email() {
		return merchant_email;
	}
	public void setMerchant_email(String merchant_email) {
		this.merchant_email = merchant_email;
	}
	public String getProduct_type() {
		return product_type;
	}
	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}  
	
	
}
