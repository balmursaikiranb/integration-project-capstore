package com.cg.PlpBackEnd.service.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.PlpBackEnd.beans.CommonFeedback;



@Repository
public interface IFeedbackRepository extends CrudRepository<CommonFeedback, Integer>{

}
