package com.cg.PlpBackEnd.service.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.PlpBackEnd.beans.Product;




@Repository
public interface IProductRepo extends CrudRepository<Product, Integer>{

}
