package com.cg.PlpBackEnd.service.repo;

public class PlpRepoImpl {

}
