package com.cg.PlpBackEnd.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Merchant {
		@Id
		private String merchant_email ;
		private String  merchant_category ;
		private String merchant_ifsc_code ;
		private String merchant_location;
		private String merchant_mobile ;
		private String merchant_name ;
		private String merchant_account_number;
		private int rating;
		private String address;
		private int code;
		private String password;
		private String producttype;
		private int product_id;
		private String merchant_type;
		private String customer_feedback;
		private String merchant_response;
		public Merchant() {
			
		}
		
		
		@Override
		public String toString() {
			return "Merchant [merchant_email=" + merchant_email + ", merchant_category=" + merchant_category
					+ ", merchant_ifsc_code=" + merchant_ifsc_code + ", merchant_location=" + merchant_location
					+ ", merchant_mobile=" + merchant_mobile + ", merchant_name=" + merchant_name
					+ ", merchant_account_number=" + merchant_account_number + ", rating=" + rating + ", address="
					+ address + ", code=" + code + ", password=" + password + ", producttype=" + producttype
					+ ", product_id=" + product_id + ", merchant_type=" + merchant_type + ", customer_feedback="
					+ customer_feedback + ", merchant_response=" + merchant_response + "]";
		}


		public String getCustomer_feedback() {
			return customer_feedback;
		}


		public void setCustomer_feedback(String customer_feedback) {
			this.customer_feedback = customer_feedback;
		}


		public String getMerchant_response() {
			return merchant_response;
		}


		public void setMerchant_response(String merchant_response) {
			this.merchant_response = merchant_response;
		}


		public String getMerchant_email() {
			return merchant_email;
		}
		public void setMerchant_email(String merchant_email) {
			this.merchant_email = merchant_email;
		}
		public String getMerchant_category() {
			return merchant_category;
		}
		public void setMerchant_category(String merchant_category) {
			this.merchant_category = merchant_category;
		}
		public String getMerchant_ifsc_code() {
			return merchant_ifsc_code;
		}
		public void setMerchant_ifsc_code(String merchant_ifsc_code) {
			this.merchant_ifsc_code = merchant_ifsc_code;
		}
		public String getMerchant_location() {
			return merchant_location;
		}
		public void setMerchant_location(String merchant_location) {
			this.merchant_location = merchant_location;
		}
		public String getMerchant_mobile() {
			return merchant_mobile;
		}
		public void setMerchant_mobile(String merchant_mobile) {
			this.merchant_mobile = merchant_mobile;
		}
		public String getMerchant_name() {
			return merchant_name;
		}
		public void setMerchant_name(String merchant_name) {
			this.merchant_name = merchant_name;
		}
		public String getMerchant_account_number() {
			return merchant_account_number;
		}
		public void setMerchant_account_number(String merchant_account_number) {
			this.merchant_account_number = merchant_account_number;
		}
		public int getRating() {
			return rating;
		}
		public void setRating(int rating) {
			this.rating = rating;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public int getCode() {
			return code;
		}
		public void setCode(int code) {
			this.code = code;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getProducttype() {
			return producttype;
		}
		public void setProducttype(String producttype) {
			this.producttype = producttype;
		}
		public int getProduct_id() {
			return product_id;
		}
		public void setProduct_id(int product_id) {
			this.product_id = product_id;
		}
		public String getMerchant_type() {
			return merchant_type;
		}
		public void setMerchant_type(String merchant_type) {
			this.merchant_type = merchant_type;
		}
		
}
